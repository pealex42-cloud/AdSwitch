# AdSwitch — prototype Android natif

Cible initiale : Android 10+ (minSdk 29), Kotlin natif.

## État actuel

Prototype v2 : filtrage DNS IPv4/UDP via VpnService (requêtes traitées en parallèle, réponse 0.0.0.0 pour les domaines bloqués).
Il contient :
- une première interface simple ;
- la déclaration du service `VpnService` ;
- une classe de stockage local de domaines.

Le service VPN n'établit volontairement pas de tunnel à ce stade : un moteur DNS incomplet peut casser la résolution DNS et la connexion réseau. Ne pas présenter cette version comme un bloqueur prêt à l'emploi.

## Prochaines étapes

1. Implémenter un moteur de paquets DNS IPv4/IPv6 avec UDP et TCP, réponses de blocage et transfert des requêtes autorisées via sockets protégées.
2. Ajouter l'import initial d'une liste embarquée et l'actualisation HTTPS manuelle avec validation, taille maximale, timeout et remplacement atomique.
3. Ajouter le vrai bouton ON/OFF, la notification du service, les erreurs et le redémarrage optionnel.
4. Tester sur Android 10 à 16, y compris Private DNS, Wi-Fi/mobile, IPv6, veille et économie d'énergie.
5. Compiler et signer un APK via une chaîne de build Android cloud ou CI.

## Build

Ouvrir ce dossier avec Android Studio ou compiler avec Gradle dans un environnement Android configuré :
`gradle assembleDebug`

L'APK debug sera normalement généré dans `app/build/outputs/apk/debug/`.

## v0.2

- Liste embarquée de ~73 000 domaines (StevenBlack/hosts) dans `app/src/main/assets/`.
- Bouton « Mettre à jour les listes » : téléchargement HTTPS, validation, remplacement atomique, rechargement à chaud du service.
- Thème clair / sombre : bouton lune / soleil en haut à droite (suit le thème du téléphone par défaut, choix mémorisé).

## v0.3

- Icône d'application (bouclier + interrupteur).
- Deux cases : « Bloquer les pubs » et « VPN + position fictive ».
- VPN : tunnel WireGuard (bibliothèque officielle) avec une config `.conf` importée (ex. serveur US gratuit Proton VPN).
- Les deux cochées : le tunnel utilise le DNS AdGuard (filtre les pubs côté serveur).
- Position fictive : AdSwitch doit être choisie comme « application de position fictive » dans les options développeur.
- Pays : liste dans `Countries.kt` (une seule entrée pour l'instant : États-Unis).

## v0.4

- Activation automatique : cocher / décocher une case applique l'état tout de suite (plus de bouton Activer).
- Les autorisations sont demandées automatiquement dans l'ordre : config WireGuard, position fictive, VPN Android.
- Onglets Accueil / Config (config WireGuard, position fictive, listes de blocage).
