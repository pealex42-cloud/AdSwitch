package fr.adswitch.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.location.Criteria
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlin.random.Random

/**
 * Service « VPN + position fictive ».
 * - monte le tunnel WireGuard (avec DNS anti-pub si demandé) ;
 * - envoie une fausse position GPS toutes les secondes (nécessite que AdSwitch soit choisie
 *   comme « application de position fictive » dans les options développeur).
 */
class ToolsService : Service() {
    private var scheduler: ScheduledExecutorService? = null
    private val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopAll()
            else -> if (!running) start(intent)
        }
        return START_NOT_STICKY
    }

    private fun start(intent: Intent?) {
        val ads = intent?.getBooleanExtra(EXTRA_ADS, false) ?: false
        val lat = intent?.getDoubleExtra(EXTRA_LAT, 0.0) ?: 0.0
        val lon = intent?.getDoubleExtra(EXTRA_LON, 0.0) ?: 0.0
        val label = intent?.getStringExtra(EXTRA_LABEL) ?: ""

        val channelId = "adswitch_vpn"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(channelId, "AdSwitch", NotificationManager.IMPORTANCE_LOW))
        val stopIntent = PendingIntent.getService(
            this, 3, Intent(this, ToolsService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("AdSwitch est actif")
            .setContentText("VPN + position : $label" + if (ads) " • pubs bloquées" else "")
            .setSmallIcon(android.R.drawable.ic_secure)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Arrêter", stopIntent)
            .build()
        startForeground(2, notification)

        running = true
        lastError = null
        thread(name = "AdSwitch-tools", isDaemon = true) {
            try {
                WgManager.up(applicationContext, ads)
            } catch (e: Exception) {
                lastError = "VPN : ${e.message ?: e.javaClass.simpleName}"
                stopAll()
                return@thread
            }
            startGps(lat, lon)
        }
    }

    private fun startGps(lat: Double, lon: Double) {
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try {
            for (p in providers) {
                try { lm.removeTestProvider(p) } catch (_: Exception) {}
                lm.addTestProvider(
                    p, false, false, false, false, true, true, true,
                    Criteria.POWER_LOW, Criteria.ACCURACY_FINE
                )
                lm.setTestProviderEnabled(p, true)
            }
        } catch (e: SecurityException) {
            lastError = "GPS : choisis AdSwitch comme « application de position fictive » dans les options développeur"
            return
        } catch (e: Exception) {
            lastError = "GPS : ${e.message ?: e.javaClass.simpleName}"
            return
        }
        val ex = Executors.newSingleThreadScheduledExecutor()
        scheduler = ex
        ex.scheduleAtFixedRate({
            for (p in providers) {
                try {
                    val loc = Location(p)
                    // petit bruit aléatoire (quelques mètres) pour que la position paraisse naturelle
                    loc.latitude = lat + Random.nextDouble(-0.00003, 0.00003)
                    loc.longitude = lon + Random.nextDouble(-0.00003, 0.00003)
                    loc.accuracy = 8f
                    loc.altitude = 10.0
                    loc.time = System.currentTimeMillis()
                    loc.elapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos()
                    lm.setTestProviderLocation(p, loc)
                } catch (_: Exception) {
                }
            }
        }, 0L, 1L, TimeUnit.SECONDS)
    }

    private fun stopGps() {
        scheduler?.shutdownNow()
        scheduler = null
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        for (p in providers) {
            try { lm.removeTestProvider(p) } catch (_: Exception) {}
        }
    }

    private fun stopAll() {
        running = false
        stopGps()
        thread(name = "AdSwitch-tools-stop", isDaemon = true) {
            try { WgManager.down() } catch (_: Exception) {}
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    override fun onDestroy() {
        running = false
        scheduler?.shutdownNow()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "fr.adswitch.app.TOOLS_START"
        const val ACTION_STOP = "fr.adswitch.app.TOOLS_STOP"
        const val EXTRA_ADS = "ads"
        const val EXTRA_LAT = "lat"
        const val EXTRA_LON = "lon"
        const val EXTRA_LABEL = "label"
        @Volatile var running = false
        @Volatile var lastError: String? = null
    }
}
