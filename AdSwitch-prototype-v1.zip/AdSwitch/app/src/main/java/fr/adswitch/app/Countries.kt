package fr.adswitch.app

import android.content.Context

/** Pays proposés pour la position fictive. Pour en ajouter un : une ligne dans `list` + une clé dans i18n.json. */
data class Country(val key: String, val lat: Double, val lon: Double) {
    fun label(ctx: Context): String = I18n.t(ctx, key)
}

object Countries {
    val list = listOf(
        Country("country_us", 40.7128, -74.0060)
    )
}
