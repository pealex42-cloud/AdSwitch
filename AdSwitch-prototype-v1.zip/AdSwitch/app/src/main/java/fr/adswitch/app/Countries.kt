package fr.adswitch.app

/** Pays proposés pour la position fictive. Pour en ajouter un : une ligne dans `list`. */
data class Country(val label: String, val lat: Double, val lon: Double)

object Countries {
    val list = listOf(
        Country("🇺🇸 États-Unis (New York)", 40.7128, -74.0060)
    )
}
