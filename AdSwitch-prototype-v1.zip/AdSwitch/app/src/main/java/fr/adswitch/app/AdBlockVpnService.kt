package fr.adswitch.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * First functional prototype: IPv4 UDP DNS interception only.
 * Only the synthetic DNS server address is routed into the TUN; other IPv4
 * traffic is left to Android's normal network path.
 */
class AdBlockVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    private val running = AtomicBoolean(false)
    private var worker: Thread? = null
    private val dnsAddress = byteArrayOf(10, 111, 0, 2)
    private val gatewayAddress = byteArrayOf(10, 111, 0, 1)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopFiltering()
            else -> if (!running.get()) startFiltering()
        }
        return START_NOT_STICKY
    }

    private fun startFiltering() {
        try {
            val channelId = "adswitch_vpn"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(channelId, "AdSwitch", NotificationManager.IMPORTANCE_LOW)
                getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
            }
            val stopIntent = PendingIntent.getService(
                this, 2, Intent(this, AdBlockVpnService::class.java).setAction(ACTION_STOP),
                PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
            )
            val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Notification.Builder(this, channelId)
            } else {
                @Suppress("DEPRECATION") Notification.Builder(this)
            }.setContentTitle("AdSwitch est actif")
                .setContentText("Filtrage DNS local en cours")
                .setSmallIcon(android.R.drawable.ic_secure)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Arrêter", stopIntent)
                .build()
            startForeground(1, notification)

            val builder = Builder()
                .setSession("AdSwitch")
                .setMtu(1500)
                .addAddress(InetAddress.getByAddress(gatewayAddress), 32)
                .addDnsServer(InetAddress.getByAddress(dnsAddress))
                .addRoute(InetAddress.getByAddress(dnsAddress), 32)
            tun = builder.establish() ?: error("Android n'a pas créé le VPN")
            running.set(true)
            worker = thread(name = "AdSwitch-DNS", isDaemon = true) { packetLoop() }
        } catch (e: Exception) {
            running.set(false)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun packetLoop() {
        val fd = tun ?: return
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val buffer = ByteArray(32767)
        while (running.get()) {
            try {
                val count = input.read(buffer)
                if (count <= 0) continue
                val packet = buffer.copyOf(count)
                val parsed = parseDnsPacket(packet) ?: continue
                val query = parsed.dns
                val hostname = dnsQuestionName(query) ?: continue
                val blocked = BlocklistStore(this).load().any { hostname == it || hostname.endsWith(".$it") }
                val answerDns = if (blocked) blockedResponse(query) else forwardDns(query)
                if (answerDns != null) {
                    val reply = buildUdpIpv4(dnsAddress, parsed.sourceIp, 53, parsed.sourcePort, answerDns)
                    output.write(reply)
                }
            } catch (_: Exception) {
                if (!running.get()) break
            }
        }
    }

    private data class DnsPacket(val sourceIp: ByteArray, val sourcePort: Int, val dns: ByteArray)

    private fun parseDnsPacket(p: ByteArray): DnsPacket? {
        if (p.size < 28 || (p[0].toInt() and 0xF0) != 0x40) return null
        val ihl = (p[0].toInt() and 0x0F) * 4
        if (ihl < 20 || p.size < ihl + 8 + 12 || (p[9].toInt() and 255) != 17) return null
        val dst = p.copyOfRange(16, 20)
        if (!dst.contentEquals(dnsAddress)) return null
        val srcPort = u16(p, ihl)
        val dstPort = u16(p, ihl + 2)
        if (dstPort != 53) return null
        val udpLength = u16(p, ihl + 4)
        if (udpLength < 20 || ihl + udpLength > p.size) return null
        return DnsPacket(p.copyOfRange(12, 16), srcPort, p.copyOfRange(ihl + 8, ihl + udpLength))
    }

    private fun forwardDns(dns: ByteArray): ByteArray? {
        var socket: DatagramSocket? = null
        return try {
            socket = DatagramSocket()
            if (!protect(socket)) return null
            socket.soTimeout = 2500
            val server = InetAddress.getByName("1.1.1.1")
            socket.send(DatagramPacket(dns, dns.size, server, 53))
            val data = ByteArray(4096)
            val response = DatagramPacket(data, data.size)
            socket.receive(response)
            data.copyOf(response.length)
        } catch (_: Exception) {
            null
        } finally {
            socket?.close()
        }
    }

    private fun blockedResponse(query: ByteArray): ByteArray {
        if (query.size < 12) return query
        val r = query.copyOf()
        r[2] = ((r[2].toInt() and 0x01) or 0x80 or (r[2].toInt() and 0x78)).toByte()
        r[3] = ((r[3].toInt() and 0xF0) or 0x03).toByte() // NXDOMAIN
        r[6] = 0; r[7] = 0
        r[8] = 0; r[9] = 0
        r[10] = 0; r[11] = 0
        return r
    }

    private fun dnsQuestionName(dns: ByteArray): String? {
        if (dns.size < 17 || u16(dns, 4) < 1) return null
        var i = 12
        val parts = mutableListOf<String>()
        while (i < dns.size) {
            val len = dns[i++].toInt() and 255
            if (len == 0) break
            if (len > 63 || i + len > dns.size) return null
            parts.add(String(dns, i, len, Charsets.US_ASCII).lowercase())
            i += len
        }
        return parts.takeIf { it.isNotEmpty() }?.joinToString(".")
    }

    private fun buildUdpIpv4(src: ByteArray, dst: ByteArray, srcPort: Int, dstPort: Int, payload: ByteArray): ByteArray {
        val udpLen = 8 + payload.size
        val p = ByteArray(20 + udpLen)
        p[0] = 0x45
        p[1] = 0
        put16(p, 2, p.size)
        put16(p, 4, 0)
        put16(p, 6, 0x4000)
        p[8] = 64
        p[9] = 17
        System.arraycopy(src, 0, p, 12, 4)
        System.arraycopy(dst, 0, p, 16, 4)
        put16(p, 10, checksum(p, 0, 20))
        put16(p, 20, srcPort)
        put16(p, 22, dstPort)
        put16(p, 24, udpLen)
        put16(p, 26, 0) // IPv4 UDP checksum may be zero
        System.arraycopy(payload, 0, p, 28, payload.size)
        return p
    }

    private fun u16(a: ByteArray, i: Int): Int = ((a[i].toInt() and 255) shl 8) or (a[i + 1].toInt() and 255)
    private fun put16(a: ByteArray, i: Int, v: Int) { a[i] = (v shr 8).toByte(); a[i + 1] = v.toByte() }
    private fun checksum(a: ByteArray, off: Int, len: Int): Int {
        var sum = 0L
        var i = off
        while (i + 1 < off + len) { sum += u16(a, i).toLong(); i += 2 }
        if (i < off + len) sum += (a[i].toInt() and 255).toLong() shl 8
        while ((sum shr 16) != 0L) sum = (sum and 0xffff) + (sum shr 16)
        return sum.inv().toInt() and 0xffff
    }

    private fun stopFiltering() {
        running.set(false)
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        running.set(false)
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "fr.adswitch.app.START"
        const val ACTION_STOP = "fr.adswitch.app.STOP"
    }
}
