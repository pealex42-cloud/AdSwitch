package fr.adswitch.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.concurrent.thread

/**
 * Filtrage DNS local (IPv4 / UDP) via un VPN local.
 * Seule l'adresse DNS synthétique est routée dans le TUN : le reste du trafic
 * passe par le réseau normal d'Android.
 */
class AdBlockVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    private var pool: ExecutorService? = null
    private val writeLock = Any()
    @Volatile private var blocklist: Set<String> = emptySet()

    private val dnsAddress = byteArrayOf(10, 111, 0, 2)
    private val gatewayAddress = byteArrayOf(10, 111, 0, 1)
    private val upstreams = listOf("1.1.1.1", "9.9.9.9")

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopFiltering()
            ACTION_RELOAD -> {
                if (isRunning) {
                    thread(name = "AdSwitch-reload", isDaemon = true) {
                        try { blocklist = BlocklistStore(this).load() } catch (_: Exception) {}
                    }
                } else {
                    stopSelf()
                }
            }
            else -> if (!isRunning) startFiltering()
        }
        return START_NOT_STICKY
    }

    private fun startFiltering() {
        try {
            val channelId = "adswitch_vpn"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(channelId, "AdSwitch", NotificationManager.IMPORTANCE_LOW)
                getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
            }
            val stopIntent = PendingIntent.getService(
                this, 2, Intent(this, AdBlockVpnService::class.java).setAction(ACTION_STOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Notification.Builder(this, channelId)
            } else {
                @Suppress("DEPRECATION") Notification.Builder(this)
            }.setContentTitle(I18n.t(this, "notif_title"))
                .setContentText(I18n.t(this, "notif_dns"))
                .setSmallIcon(android.R.drawable.ic_secure)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, I18n.t(this, "notif_stop"), stopIntent)
                .build()
            startForeground(1, notification)

            blocklist = BlocklistStore(this).load()

            val builder = Builder()
                .setSession("AdSwitch")
                .setMtu(1500)
                .addAddress(InetAddress.getByAddress(gatewayAddress), 32)
                .addDnsServer(InetAddress.getByAddress(dnsAddress))
                .addRoute(InetAddress.getByAddress(dnsAddress), 32)
            val fd = builder.establish() ?: error("Android n'a pas créé le VPN")
            tun = fd
            pool = Executors.newFixedThreadPool(16)
            isRunning = true
            val input = FileInputStream(fd.fileDescriptor)
            val output = FileOutputStream(fd.fileDescriptor)
            worker = thread(name = "AdSwitch-DNS", isDaemon = true) { packetLoop(input, output) }
        } catch (e: Exception) {
            cleanup()
            stopSelf()
        }
    }

    private fun packetLoop(input: FileInputStream, output: FileOutputStream) {
        val buffer = ByteArray(32767)
        while (isRunning) {
            val count = try {
                input.read(buffer)
            } catch (e: IOException) {
                break
            }
            if (count <= 0) continue
            val parsed = parseDnsPacket(buffer.copyOf(count)) ?: continue
            val hostname = dnsQuestionName(parsed.dns) ?: continue
            try {
                // Chaque requête est traitée dans son propre thread :
                // une requête lente ne bloque plus toutes les autres.
                pool?.execute { handleQuery(parsed, hostname, output) }
            } catch (e: Exception) {
                break
            }
        }
    }

    private fun handleQuery(parsed: DnsPacket, hostname: String, output: FileOutputStream) {
        try {
            val answer = if (isBlocked(hostname)) {
                blockedResponse(parsed.dns)
            } else {
                forwardDns(parsed.dns) ?: dnsError(parsed.dns, 2) // SERVFAIL plutôt que silence
            }
            val reply = buildUdpIpv4(dnsAddress, parsed.sourceIp, 53, parsed.sourcePort, answer)
            synchronized(writeLock) { output.write(reply) }
        } catch (_: Exception) {
        }
    }

    private fun isBlocked(hostname: String): Boolean {
        val list = blocklist
        var h = hostname
        while (true) {
            if (h in list) return true
            val dot = h.indexOf('.')
            if (dot < 0) return false
            h = h.substring(dot + 1)
        }
    }

    private class DnsPacket(val sourceIp: ByteArray, val sourcePort: Int, val dns: ByteArray)

    private fun parseDnsPacket(p: ByteArray): DnsPacket? {
        if (p.size < 28 || (p[0].toInt() and 0xF0) != 0x40) return null
        val ihl = (p[0].toInt() and 0x0F) * 4
        if (ihl < 20 || p.size < ihl + 8 + 12 || (p[9].toInt() and 255) != 17) return null
        val dst = p.copyOfRange(16, 20)
        if (!dst.contentEquals(dnsAddress)) return null
        val srcPort = u16(p, ihl)
        val dstPort = u16(p, ihl + 2)
        if (dstPort != 53) return null
        val udpLength = u16(p, ihl + 4)
        if (udpLength < 20 || ihl + udpLength > p.size) return null
        return DnsPacket(p.copyOfRange(12, 16), srcPort, p.copyOfRange(ihl + 8, ihl + udpLength))
    }

    private fun forwardDns(dns: ByteArray): ByteArray? {
        for (host in upstreams) {
            var socket: DatagramSocket? = null
            try {
                socket = DatagramSocket()
                if (!protect(socket)) continue
                socket.soTimeout = 2000
                socket.send(DatagramPacket(dns, dns.size, InetAddress.getByName(host), 53))
                val data = ByteArray(4096)
                val response = DatagramPacket(data, data.size)
                socket.receive(response)
                return data.copyOf(response.length)
            } catch (_: Exception) {
                // on essaie le serveur suivant
            } finally {
                socket?.close()
            }
        }
        return null
    }

    /** Fin de la section "question" (nom + type + classe), ou null si paquet invalide. */
    private fun questionEnd(dns: ByteArray): Int? {
        var i = 12
        while (i < dns.size) {
            val len = dns[i].toInt() and 255
            if (len == 0) {
                val end = i + 1 + 4
                return if (end <= dns.size) end else null
            }
            if (len > 63) return null
            i += len + 1
        }
        return null
    }

    /** Réponse DNS vide avec le code d'erreur donné (2 = SERVFAIL, 3 = NXDOMAIN). */
    private fun dnsError(query: ByteArray, rcode: Int): ByteArray {
        val end = questionEnd(query) ?: query.size
        val r = query.copyOf(end)
        if (r.size < 12) return r
        r[2] = (0x80 or (r[2].toInt() and 0x79)).toByte() // QR=1, garde opcode + RD
        r[3] = (0x80 or rcode).toByte()                   // RA=1 + rcode
        for (i in 6..11) r[i] = 0
        return r
    }

    /** Domaine bloqué : 0.0.0.0 pour A, :: pour AAAA, NXDOMAIN pour le reste. */
    private fun blockedResponse(query: ByteArray): ByteArray {
        val end = questionEnd(query) ?: return dnsError(query, 2)
        val qtype = u16(query, end - 4)
        val rdata = when (qtype) {
            1 -> ByteArray(4)
            28 -> ByteArray(16)
            else -> return dnsError(query, 3)
        }
        val head = dnsError(query, 0)
        val out = ByteArray(end + 12 + rdata.size)
        System.arraycopy(head, 0, out, 0, end)
        put16(out, 6, 1)               // ANCOUNT = 1
        put16(out, end, 0xC00C)        // pointeur vers le nom de la question
        put16(out, end + 2, qtype)
        put16(out, end + 4, 1)         // classe IN
        put16(out, end + 6, 0)         // TTL (poids fort)
        put16(out, end + 8, 60)        // TTL = 60 s
        put16(out, end + 10, rdata.size)
        System.arraycopy(rdata, 0, out, end + 12, rdata.size)
        return out
    }

    private fun dnsQuestionName(dns: ByteArray): String? {
        if (dns.size < 17 || u16(dns, 4) < 1) return null
        var i = 12
        val parts = mutableListOf<String>()
        while (i < dns.size) {
            val len = dns[i++].toInt() and 255
            if (len == 0) break
            if (len > 63 || i + len > dns.size) return null
            parts.add(String(dns, i, len, Charsets.US_ASCII).lowercase())
            i += len
        }
        return parts.takeIf { it.isNotEmpty() }?.joinToString(".")
    }

    private fun buildUdpIpv4(src: ByteArray, dst: ByteArray, srcPort: Int, dstPort: Int, payload: ByteArray): ByteArray {
        val udpLen = 8 + payload.size
        val p = ByteArray(20 + udpLen)
        p[0] = 0x45
        p[1] = 0
        put16(p, 2, p.size)
        put16(p, 4, 0)
        put16(p, 6, 0x4000)
        p[8] = 64
        p[9] = 17
        System.arraycopy(src, 0, p, 12, 4)
        System.arraycopy(dst, 0, p, 16, 4)
        put16(p, 10, checksum(p, 0, 20))
        put16(p, 20, srcPort)
        put16(p, 22, dstPort)
        put16(p, 24, udpLen)
        put16(p, 26, 0) // checksum UDP optionnel en IPv4
        System.arraycopy(payload, 0, p, 28, payload.size)
        return p
    }

    private fun u16(a: ByteArray, i: Int): Int = ((a[i].toInt() and 255) shl 8) or (a[i + 1].toInt() and 255)
    private fun put16(a: ByteArray, i: Int, v: Int) { a[i] = (v shr 8).toByte(); a[i + 1] = v.toByte() }
    private fun checksum(a: ByteArray, off: Int, len: Int): Int {
        var sum = 0L
        var i = off
        while (i + 1 < off + len) { sum += u16(a, i).toLong(); i += 2 }
        if (i < off + len) sum += (a[i].toInt() and 255).toLong() shl 8
        while ((sum shr 16) != 0L) sum = (sum and 0xffff) + (sum shr 16)
        return sum.inv().toInt() and 0xffff
    }

    private fun cleanup() {
        isRunning = false
        pool?.shutdownNow()
        pool = null
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun stopFiltering() {
        cleanup()
        stopSelf()
    }

    override fun onRevoke() {
        // L'utilisateur a coupé le VPN depuis les réglages Android
        stopFiltering()
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "fr.adswitch.app.START"
        const val ACTION_STOP = "fr.adswitch.app.STOP"
        const val ACTION_RELOAD = "fr.adswitch.app.RELOAD"
        @Volatile var isRunning = false
    }
}
