package fr.adswitch.app

import android.content.Context
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.ByteArrayInputStream
import java.io.File

/**
 * Tunnel WireGuard (bibliothèque officielle). La config (.conf) est importée par l'utilisateur
 * (ex. fichier gratuit généré sur son compte Proton VPN) et stockée localement.
 */
object WgManager {
    private const val FILE = "wg.conf"
    private const val AD_DNS = "DNS = 94.140.14.14, 94.140.15.15" // AdGuard DNS : filtre les pubs côté serveur

    @Volatile private var backend: GoBackend? = null

    private val tunnel = object : Tunnel {
        override fun getName(): String = "adswitch"
        override fun onStateChange(newState: Tunnel.State) {}
    }

    private fun file(ctx: Context) = File(ctx.filesDir, FILE)

    fun hasConfig(ctx: Context): Boolean = file(ctx).exists()

    /** Ex. « 185.159.x.x:51820 », ou null si aucune config. */
    fun endpoint(ctx: Context): String? {
        val f = file(ctx)
        if (!f.exists()) return null
        return Regex("(?im)^\\s*Endpoint\\s*=\\s*(.+)$").find(f.readText())?.groupValues?.get(1)?.trim()
    }

    /** Valide puis enregistre la config. Lève une exception si elle est invalide. */
    fun importConfig(ctx: Context, text: String) {
        require(text.length <= 64 * 1024) { "Fichier trop volumineux" }
        Config.parse(ByteArrayInputStream(text.toByteArray()))
        file(ctx).writeText(text)
    }

    /** Remplace le DNS du tunnel par un DNS filtrant les pubs. */
    private fun withAdDns(raw: String): String {
        val out = ArrayList<String>()
        var inInterface = false
        var inserted = false
        for (line in raw.lines()) {
            val t = line.trim()
            if (t.startsWith("[")) {
                if (inInterface && !inserted) { out.add(AD_DNS); inserted = true }
                inInterface = t.equals("[Interface]", ignoreCase = true)
                out.add(line)
                continue
            }
            if (inInterface && t.lowercase().startsWith("dns")) continue
            out.add(line)
        }
        if (inInterface && !inserted) out.add(AD_DNS)
        return out.joinToString("\n")
    }

    /** Monte le tunnel (bloquant : à appeler hors du thread principal). */
    @Synchronized
    fun up(ctx: Context, blockAds: Boolean) {
        val raw = file(ctx).readText()
        val text = if (blockAds) withAdDns(raw) else raw
        val config = Config.parse(ByteArrayInputStream(text.toByteArray()))
        val b = backend ?: GoBackend(ctx.applicationContext).also { backend = it }
        b.setState(tunnel, Tunnel.State.UP, config)
    }

    /** Coupe le tunnel (bloquant). */
    @Synchronized
    fun down() {
        backend?.setState(tunnel, Tunnel.State.DOWN, null)
    }
}
