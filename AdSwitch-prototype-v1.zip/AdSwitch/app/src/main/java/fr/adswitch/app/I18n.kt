package fr.adswitch.app

import android.content.Context
import org.json.JSONObject
import java.util.Locale

class Lang(val code: String, val flag: String, val name: String)

/** Traductions : fichier assets/i18n.json  { "clé": { "fr": "...", "en": "..." } }. */
object I18n {
    val languages = listOf(
        Lang("fr", "🇫🇷", "Français"),
        Lang("en", "🇺🇸", "English"),
        Lang("es", "🇪🇸", "Español"),
        Lang("de", "🇩🇪", "Deutsch"),
        Lang("it", "🇮🇹", "Italiano"),
        Lang("pt", "🇧🇷", "Português"),
        Lang("ru", "🇷🇺", "Русский"),
        Lang("zh", "🇨🇳", "中文")
    )

    @Volatile private var table: JSONObject? = null

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("ui", Context.MODE_PRIVATE)

    /** Langue choisie, sinon celle du téléphone si elle est proposée, sinon l'anglais. */
    fun code(ctx: Context): String {
        val saved = prefs(ctx).getString("lang", null)
        if (saved != null && languages.any { it.code == saved }) return saved
        val system = Locale.getDefault().language
        return if (languages.any { it.code == system }) system else "en"
    }

    fun current(ctx: Context): Lang = languages.first { it.code == code(ctx) }

    fun set(ctx: Context, code: String) {
        prefs(ctx).edit().putString("lang", code).apply()
    }

    /** Texte traduit ; {0}, {1}… sont remplacés par les arguments. */
    fun t(ctx: Context, key: String, vararg args: Any?): String {
        val all = table ?: synchronized(this) {
            table ?: JSONObject(
                ctx.applicationContext.assets.open("i18n.json").bufferedReader().use { it.readText() }
            ).also { table = it }
        }
        val entry = all.optJSONObject(key) ?: return key
        var s = entry.optString(code(ctx), "")
        if (s.isEmpty()) s = entry.optString("en", "")
        if (s.isEmpty()) s = entry.optString("fr", key)
        for ((i, a) in args.withIndex()) s = s.replace("{" + i + "}", a.toString())
        return s
    }
}
