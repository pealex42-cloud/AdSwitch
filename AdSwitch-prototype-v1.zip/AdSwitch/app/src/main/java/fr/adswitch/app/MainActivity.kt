package fr.adswitch.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var themeButton: TextView
    private val texts = mutableListOf<TextView>()
    private var dark = false
    private lateinit var toggle: Button
    private lateinit var updateButton: Button
    private lateinit var listInfo: TextView

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("ui", MODE_PRIVATE)
        dark = if (prefs.contains("dark")) prefs.getBoolean("dark", false)
        else (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(32, 48, 32, 32)
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            // Android 15 : l'appli passe sous la barre d'état, on décale le contenu
            setOnApplyWindowInsetsListener { v, insets ->
                v.setPadding(32, 16 + insets.systemWindowInsetTop, 32, 32 + insets.systemWindowInsetBottom)
                insets
            }
        }
        root = layout

        // Bouton lune / soleil en haut à droite
        themeButton = TextView(this).apply {
            textSize = 26f
            setPadding(24, 8, 24, 8)
            contentDescription = "Changer de thème"
            setOnClickListener {
                dark = !dark
                prefs.edit().putBoolean("dark", dark).apply()
                applyTheme()
            }
        }
        layout.addView(
            themeButton,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.END }
        )

        layout.addView(TextView(this).apply { text = "AdSwitch"; textSize = 30f; gravity = Gravity.CENTER }.also { texts.add(it) })
        layout.addView(TextView(this).apply {
            text = "Bloqueur DNS local • version expérimentale"
            textSize = 15f; gravity = Gravity.CENTER; setPadding(0, 8, 0, 28)
        }.also { texts.add(it) })
        status = TextView(this).apply { textSize = 17f; gravity = Gravity.CENTER; setPadding(0, 12, 0, 20) }
        texts.add(status)
        toggle = Button(this).apply {
            setOnClickListener {
                if (AdBlockVpnService.isRunning) stopVpn() else {
                    val permission = VpnService.prepare(this@MainActivity)
                    if (permission != null) startActivityForResult(permission, REQUEST_VPN)
                    else startVpn()
                }
            }
        }
        updateButton = Button(this).apply {
            text = "Mettre à jour les listes"
            setOnClickListener { updateLists() }
        }
        listInfo = TextView(this).apply { textSize = 13f; gravity = Gravity.CENTER; setPadding(0, 16, 0, 0) }
        texts.add(listInfo)
        layout.addView(status)
        layout.addView(toggle)
        layout.addView(updateButton)
        layout.addView(listInfo)
        layout.addView(TextView(this).apply {
            text = "Filtrage DNS IPv4 expérimental. Désactive le « DNS privé » d'Android et le « DNS sécurisé » de Chrome si rien n'est bloqué."
            textSize = 13f; setPadding(0, 24, 0, 0)
        }.also { texts.add(it) })
        setContentView(layout)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
        applyTheme()
        refresh()
        showListInfo()
    }

    @Suppress("DEPRECATION")
    private fun applyTheme() {
        val bg = if (dark) 0xFF121212.toInt() else 0xFFFAFAFA.toInt()
        val fg = if (dark) 0xFFEEEEEE.toInt() else 0xFF222222.toInt()
        val buttonBg = if (dark) 0xFF2E2E2E.toInt() else 0xFFD6D8D8.toInt()
        root.setBackgroundColor(bg)
        window.decorView.setBackgroundColor(bg)
        texts.forEach { it.setTextColor(fg) }
        val buttonText = ColorStateList(
            arrayOf(intArrayOf(-android.R.attr.state_enabled), intArrayOf()),
            intArrayOf((fg and 0x00FFFFFF) or 0x66000000, fg)
        )
        for (b in listOf(toggle, updateButton)) {
            b.setTextColor(buttonText)
            b.backgroundTintList = ColorStateList.valueOf(buttonBg)
        }
        themeButton.text = if (dark) "☀️" else "🌙"
        // Icônes de la barre d'état / de navigation lisibles dans les deux thèmes
        var flags = window.decorView.systemUiVisibility
        val light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            (if (Build.VERSION.SDK_INT >= 26) View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else 0)
        flags = if (dark) flags and light.inv() else flags or light
        window.decorView.systemUiVisibility = flags
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        if (AdBlockVpnService.isRunning) {
            status.text = "Protection active"
            toggle.text = "Désactiver le blocage"
        } else {
            status.text = "Protection désactivée"
            toggle.text = "Activer le blocage"
        }
    }

    private fun showListInfo(prefix: String = "") {
        Thread {
            val info = try {
                val store = BlocklistStore(this)
                val count = store.load().size
                val date = java.text.DateFormat.getDateInstance().format(java.util.Date(store.lastModified()))
                "$count domaines bloqués • liste du $date"
            } catch (e: Exception) {
                "Liste indisponible : ${e.message}"
            }
            runOnUiThread { listInfo.text = if (prefix.isEmpty()) info else "$prefix\n$info" }
        }.start()
    }

    private fun updateLists() {
        updateButton.isEnabled = false
        listInfo.text = "Téléchargement en cours…"
        Thread {
            var prefix: String
            try {
                BlocklistStore(this).update()
                prefix = "Mise à jour réussie ✔"
                if (AdBlockVpnService.isRunning) {
                    startService(Intent(this, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_RELOAD))
                }
            } catch (e: Exception) {
                prefix = "Échec de la mise à jour : ${e.message}"
            }
            runOnUiThread {
                updateButton.isEnabled = true
                showListInfo(prefix)
            }
        }.start()
    }

    private fun startVpn() {
        val intent = Intent(this, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_START)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        status.text = "Démarrage…"
        toggle.postDelayed({ refresh() }, 800)
    }

    private fun stopVpn() {
        startService(Intent(this, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_STOP))
        status.text = "Arrêt…"
        toggle.postDelayed({ refresh() }, 500)
    }

    @Deprecated("Deprecated in Android API; retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_VPN && resultCode == RESULT_OK) startVpn()
    }

    companion object { private const val REQUEST_VPN = 1001 }
}
