package fr.adswitch.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Typeface
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var root: LinearLayout
    private lateinit var homeBox: LinearLayout
    private lateinit var configBox: LinearLayout
    private lateinit var tabHome: TextView
    private lateinit var tabConfig: TextView
    private lateinit var themeButton: TextView
    private lateinit var status: TextView
    private lateinit var cbAds: CheckBox
    private lateinit var cbVpn: CheckBox
    private lateinit var countryButton: Button
    private lateinit var importButton: Button
    private lateinit var devButton: Button
    private lateinit var updateButton: Button
    private lateinit var listInfo: TextView
    private lateinit var vpnInfo: TextView
    private lateinit var mockInfo: TextView
    private val texts = mutableListOf<TextView>()
    private val buttons = mutableListOf<Button>()
    private val checkboxes = mutableListOf<CheckBox>()
    private var dark = false
    private var countryIndex = 0

    // Enchaînement automatique des autorisations
    private var suppressChecks = false
    private var wantPrompt = false
    private var mockAsked = false
    private var awaitingMock = false

    private fun label(t: String, size: Float, top: Int = 0): TextView =
        TextView(this).apply {
            text = t; textSize = size; gravity = Gravity.CENTER; setPadding(0, top, 0, 0)
        }.also { texts.add(it) }

    private fun button(t: String, onClick: () -> Unit): Button =
        Button(this).apply { text = t; setOnClickListener { onClick() } }.also { buttons.add(it) }

    private fun checkbox(t: String, key: String, default: Boolean): CheckBox =
        CheckBox(this).apply {
            text = t
            textSize = 18f
            setPadding(16, 16, 16, 16)
            isChecked = prefs.getBoolean(key, default)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(key, checked).apply()
                if (suppressChecks) return@setOnCheckedChangeListener
                if (key == "vpn" && !checked) mockAsked = false
                ToolsService.lastError = null
                scheduleApply(300L, prompt = true)
            }
        }.also { texts.add(it); checkboxes.add(it) }

    private fun tab(t: String, index: Int): TextView =
        TextView(this).apply {
            text = t; textSize = 18f; setPadding(24, 16, 24, 16)
            setOnClickListener { showTab(index) }
        }.also { texts.add(it) }

    private fun box(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("ui", MODE_PRIVATE)
        dark = if (prefs.contains("dark")) prefs.getBoolean("dark", false)
        else (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        countryIndex = prefs.getInt("country", 0).coerceIn(0, Countries.list.size - 1)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(32, 48, 32, 32)
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            // Android 15 : l'appli passe sous la barre d'état, on décale le contenu
            setOnApplyWindowInsetsListener { v, insets ->
                v.setPadding(32, 16 + insets.systemWindowInsetTop, 32, 32 + insets.systemWindowInsetBottom)
                insets
            }
        }

        // ----- En-tête : onglets + lune / soleil -----
        themeButton = TextView(this).apply {
            textSize = 26f
            setPadding(24, 8, 24, 8)
            contentDescription = "Changer de thème"
            setOnClickListener {
                dark = !dark
                prefs.edit().putBoolean("dark", dark).apply()
                applyTheme()
            }
        }
        tabHome = tab("Accueil", 0)
        tabConfig = tab("Config", 1)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(tabHome)
            addView(tabConfig)
            addView(View(this@MainActivity), LinearLayout.LayoutParams(0, 1, 1f))
            addView(themeButton)
        }
        root.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(label("AdSwitch", 30f, 8))

        // ----- Onglet Accueil -----
        homeBox = box()
        status = label("", 17f, 16)
        homeBox.addView(status)
        cbAds = checkbox("Bloquer les pubs", "ads", false)
        cbVpn = checkbox("VPN + position fictive", "vpn", false)
        homeBox.addView(cbAds)
        homeBox.addView(cbVpn)
        countryButton = button("") { chooseCountry() }
        homeBox.addView(countryButton)
        homeBox.addView(label(
            "Coche une case : l'activation est automatique.",
            13f, 16
        ))
        root.addView(homeBox)

        // ----- Onglet Config -----
        configBox = box()
        configBox.addView(label("Serveur VPN", 18f, 16))
        importButton = button("Importer une config WireGuard (.conf)") { pickConfig() }
        configBox.addView(importButton)
        vpnInfo = label("", 13f)
        configBox.addView(vpnInfo)

        configBox.addView(label("Position fictive", 18f, 24))
        devButton = button("Autoriser la position fictive") { openDeveloperOptions() }
        configBox.addView(devButton)
        mockInfo = label("", 13f)
        configBox.addView(mockInfo)

        configBox.addView(label("Listes de blocage", 18f, 24))
        updateButton = button("Mettre à jour les listes") { updateLists() }
        configBox.addView(updateButton)
        listInfo = label("", 13f, 8)
        configBox.addView(listInfo)
        configBox.addView(label(
            "Filtrage DNS IPv4 expérimental. Désactive le « DNS privé » d'Android et le « DNS sécurisé » de Chrome si rien n'est bloqué.",
            12f, 24
        ))
        root.addView(configBox)

        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
        applyTheme()
        showTab(0)
        refresh()
        showListInfo()
        // Restaure l'état précédent (sans afficher de fenêtre d'autorisation)
        scheduleApply(500L, prompt = false)
    }

    // ---------- Apparence ----------

    private fun showTab(index: Int) {
        homeBox.visibility = if (index == 0) View.VISIBLE else View.GONE
        configBox.visibility = if (index == 1) View.VISIBLE else View.GONE
        tabHome.alpha = if (index == 0) 1f else 0.5f
        tabConfig.alpha = if (index == 1) 1f else 0.5f
        tabHome.setTypeface(null, if (index == 0) Typeface.BOLD else Typeface.NORMAL)
        tabConfig.setTypeface(null, if (index == 1) Typeface.BOLD else Typeface.NORMAL)
    }

    @Suppress("DEPRECATION")
    private fun applyTheme() {
        val bg = if (dark) 0xFF121212.toInt() else 0xFFFAFAFA.toInt()
        val fg = if (dark) 0xFFEEEEEE.toInt() else 0xFF222222.toInt()
        val buttonBg = if (dark) 0xFF2E2E2E.toInt() else 0xFFD6D8D8.toInt()
        root.setBackgroundColor(bg)
        window.decorView.setBackgroundColor(bg)
        texts.forEach { it.setTextColor(fg) }
        checkboxes.forEach { it.buttonTintList = ColorStateList.valueOf(fg) }
        val buttonText = ColorStateList(
            arrayOf(intArrayOf(-android.R.attr.state_enabled), intArrayOf()),
            intArrayOf((fg and 0x00FFFFFF) or 0x66000000, fg)
        )
        for (b in buttons) {
            b.setTextColor(buttonText)
            b.backgroundTintList = ColorStateList.valueOf(buttonBg)
        }
        themeButton.text = if (dark) "☀️" else "🌙"
        // Icônes de la barre d'état / de navigation lisibles dans les deux thèmes
        var flags = window.decorView.systemUiVisibility
        val light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            (if (Build.VERSION.SDK_INT >= 26) View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else 0)
        flags = if (dark) flags and light.inv() else flags or light
        window.decorView.systemUiVisibility = flags
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    // ---------- État ----------

    /** 0 = rien, 1 = pubs seules, 2 = VPN + position, 3 = VPN + position + pubs. */
    private fun currentMode(): Int = when {
        ToolsService.running -> if (ToolsService.adsOn) 3 else 2
        AdBlockVpnService.isRunning -> 1
        else -> 0
    }

    private fun desiredMode(): Int = when {
        cbVpn.isChecked -> if (cbAds.isChecked) 3 else 2
        cbAds.isChecked -> 1
        else -> 0
    }

    private fun isMockAllowed(): Boolean = try {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        ops.unsafeCheckOpNoThrow("android:mock_location", Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    } catch (e: Exception) {
        false
    }

    private fun refresh() {
        val error = ToolsService.lastError
        val mode = currentMode()
        status.text = when (mode) {
            1 -> "Pubs bloquées ✔"
            2 -> "VPN + position actifs ✔"
            3 -> "VPN + position + pubs actifs ✔"
            else -> error ?: "Protection désactivée"
        }
        if (mode in 2..3 && error != null) status.text = status.text.toString() + "\n⚠ " + error
        countryButton.text = "Pays : ${Countries.list[countryIndex].label}  ▾"
        val endpoint = WgManager.endpoint(this)
        vpnInfo.text = if (endpoint != null) "Config importée • serveur $endpoint" else "Aucune config importée"
        mockInfo.text = if (isMockAllowed()) "Autorisée ✔" else "Pas encore autorisée"
    }

    private fun refreshSoon() {
        root.postDelayed({ refresh() }, 800)
        root.postDelayed({ refresh() }, 2500)
    }

    override fun onResume() {
        super.onResume()
        refresh()
        if (awaitingMock) {
            // retour des options développeur : on relance pour prendre en compte l'autorisation
            awaitingMock = false
            if (ToolsService.running) stopAll()
            scheduleApply(if (ToolsService.running) 1500L else 300L, prompt = true)
        }
    }

    // ---------- Activation automatique ----------

    private val applyRunnable = Runnable {
        val p = wantPrompt
        wantPrompt = false
        applyState(p)
    }

    private fun scheduleApply(delayMs: Long, prompt: Boolean) {
        wantPrompt = wantPrompt || prompt
        root.removeCallbacks(applyRunnable)
        root.postDelayed(applyRunnable, delayMs)
    }

    /**
     * Met l'état réel du service en accord avec les cases cochées.
     * prompt = true : action de l'utilisateur, on peut ouvrir les fenêtres d'autorisation.
     */
    private fun applyState(prompt: Boolean) {
        val desired = desiredMode()
        val current = currentMode()
        if (desired == current) { refreshSoon(); return }

        if (desired != 0) {
            if (!prompt && ToolsService.lastError != null && current == 0) { refresh(); return }
            if (!prerequisitesOk(prompt)) { refresh(); return }
        }

        if (current != 0) {
            stopAll()
            // on relance après l'arrêt (si une case reste cochée)
            scheduleApply(1500L, prompt)
            refreshSoon()
            return
        }
        if (desired != 0) launch()
    }

    /** Config WireGuard, position fictive, autorisation VPN : demandées automatiquement si besoin. */
    private fun prerequisitesOk(prompt: Boolean): Boolean {
        if (cbVpn.isChecked) {
            if (!WgManager.hasConfig(this)) {
                if (prompt) {
                    toast("Choisis ta config WireGuard (.conf)")
                    pickConfig()
                }
                return false
            }
            if (prompt && !mockAsked && !isMockAllowed()) {
                mockAsked = true
                toast("Choisis AdSwitch comme appli de position fictive")
                openDeveloperOptions()
                return false
            }
        }
        val permission = VpnService.prepare(this)
        if (permission != null) {
            if (prompt) startActivityForResult(permission, REQUEST_VPN)
            return false
        }
        return true
    }

    private fun launch() {
        ToolsService.lastError = null
        if (cbVpn.isChecked) {
            val c = Countries.list[countryIndex]
            startForegroundService(
                Intent(this, ToolsService::class.java).setAction(ToolsService.ACTION_START)
                    .putExtra(ToolsService.EXTRA_ADS, cbAds.isChecked)
                    .putExtra(ToolsService.EXTRA_LAT, c.lat)
                    .putExtra(ToolsService.EXTRA_LON, c.lon)
                    .putExtra(ToolsService.EXTRA_LABEL, c.label)
            )
        } else {
            startForegroundService(Intent(this, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_START))
        }
        status.text = "Démarrage…"
        refreshSoon()
    }

    private fun stopAll() {
        if (AdBlockVpnService.isRunning) {
            startService(Intent(this, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_STOP))
        }
        if (ToolsService.running) {
            startService(Intent(this, ToolsService::class.java).setAction(ToolsService.ACTION_STOP))
        }
        refreshSoon()
    }

    private fun uncheck(box: CheckBox) {
        suppressChecks = true
        box.isChecked = false
        suppressChecks = false
    }

    // ---------- Pays, config, options développeur ----------

    private fun chooseCountry() {
        AlertDialog.Builder(this)
            .setTitle("Pays")
            .setItems(Countries.list.map { it.label }.toTypedArray()) { _, which ->
                countryIndex = which
                prefs.edit().putInt("country", which).apply()
                refresh()
                if (ToolsService.running) { stopAll(); scheduleApply(1500L, prompt = false) }
            }
            .show()
    }

    private fun pickConfig() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
        startActivityForResult(intent, REQUEST_IMPORT)
    }

    private fun importConfig(uri: Uri): Boolean {
        return try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Fichier illisible")
            WgManager.importConfig(this, String(bytes, Charsets.UTF_8))
            toast("Config importée ✔")
            true
        } catch (e: Exception) {
            toast("Config invalide : ${e.message ?: e.javaClass.simpleName}")
            false
        }
    }

    private fun openDeveloperOptions() {
        try {
            awaitingMock = true
            startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
        } catch (e: ActivityNotFoundException) {
            awaitingMock = false
            toast("Active d'abord les options développeur : Paramètres → À propos du téléphone → touche 7 fois « Numéro de build »")
        }
    }

    // ---------- Listes de blocage ----------

    private fun showListInfo(prefix: String = "") {
        Thread {
            val info = try {
                val store = BlocklistStore(this)
                val count = store.load().size
                val date = java.text.DateFormat.getDateInstance().format(java.util.Date(store.lastModified()))
                "$count domaines bloqués • liste du $date"
            } catch (e: Exception) {
                "Liste indisponible : ${e.message}"
            }
            runOnUiThread { listInfo.text = if (prefix.isEmpty()) info else "$prefix\n$info" }
        }.start()
    }

    private fun updateLists() {
        updateButton.isEnabled = false
        listInfo.text = "Téléchargement en cours…"
        Thread {
            var prefix: String
            try {
                BlocklistStore(this).update()
                prefix = "Mise à jour réussie ✔"
                if (AdBlockVpnService.isRunning) {
                    startService(Intent(this, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_RELOAD))
                }
            } catch (e: Exception) {
                prefix = "Échec de la mise à jour : ${e.message}"
            }
            runOnUiThread {
                updateButton.isEnabled = true
                showListInfo(prefix)
            }
        }.start()
    }

    @Deprecated("Deprecated in Android API; retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_VPN -> {
                if (resultCode == RESULT_OK) scheduleApply(200L, prompt = true)
                else { uncheck(cbAds); uncheck(cbVpn); prefs.edit().putBoolean("ads", false).putBoolean("vpn", false).apply() }
            }
            REQUEST_IMPORT -> {
                val uri = data?.data
                val ok = resultCode == RESULT_OK && uri != null && importConfig(uri)
                if (ok) {
                    // nouvelle config : on redémarre le VPN s'il tourne, puis on continue l'enchaînement
                    if (ToolsService.running) stopAll()
                    scheduleApply(if (ToolsService.running) 1500L else 200L, prompt = true)
                } else if (!WgManager.hasConfig(this) && cbVpn.isChecked) {
                    uncheck(cbVpn)
                    prefs.edit().putBoolean("vpn", false).apply()
                }
            }
        }
        refresh()
    }

    companion object {
        private const val REQUEST_VPN = 1001
        private const val REQUEST_IMPORT = 1002
    }
}
