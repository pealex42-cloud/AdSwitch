package fr.adswitch.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var themeButton: TextView
    private lateinit var cbAds: CheckBox
    private lateinit var cbVpn: CheckBox
    private lateinit var countryButton: Button
    private lateinit var importButton: Button
    private lateinit var devButton: Button
    private lateinit var toggle: Button
    private lateinit var updateButton: Button
    private lateinit var listInfo: TextView
    private lateinit var vpnInfo: TextView
    private val texts = mutableListOf<TextView>()
    private val buttons = mutableListOf<Button>()
    private val checkboxes = mutableListOf<CheckBox>()
    private var dark = false
    private var countryIndex = 0

    private fun label(t: String, size: Float, top: Int = 0): TextView =
        TextView(this).apply {
            text = t; textSize = size; gravity = Gravity.CENTER; setPadding(0, top, 0, 0)
        }.also { texts.add(it) }

    private fun button(t: String, onClick: () -> Unit): Button =
        Button(this).apply { text = t; setOnClickListener { onClick() } }.also { buttons.add(it) }

    private fun checkbox(t: String, key: String, default: Boolean): CheckBox =
        CheckBox(this).apply {
            text = t
            textSize = 17f
            isChecked = prefs.getBoolean(key, default)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(key, checked).apply()
                if (isActive()) toast("Désactive puis réactive pour appliquer")
            }
        }.also { texts.add(it); checkboxes.add(it) }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("ui", MODE_PRIVATE)
        dark = if (prefs.contains("dark")) prefs.getBoolean("dark", false)
        else (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        countryIndex = prefs.getInt("country", 0).coerceIn(0, Countries.list.size - 1)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(32, 48, 32, 32)
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            // Android 15 : l'appli passe sous la barre d'état, on décale le contenu
            setOnApplyWindowInsetsListener { v, insets ->
                v.setPadding(32, 16 + insets.systemWindowInsetTop, 32, 32 + insets.systemWindowInsetBottom)
                insets
            }
        }

        // Bouton lune / soleil en haut à droite
        themeButton = TextView(this).apply {
            textSize = 26f
            setPadding(24, 8, 24, 8)
            contentDescription = "Changer de thème"
            setOnClickListener {
                dark = !dark
                prefs.edit().putBoolean("dark", dark).apply()
                applyTheme()
            }
        }
        root.addView(
            themeButton,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.END }
        )

        root.addView(label("AdSwitch", 30f))
        root.addView(label("Pubs • VPN • position fictive", 15f, 8))
        status = label("", 17f, 24)
        root.addView(status)

        cbAds = checkbox("Bloquer les pubs", "ads", true)
        cbVpn = checkbox("VPN + position fictive", "vpn", false)
        root.addView(cbAds)
        root.addView(cbVpn)

        countryButton = button("") { chooseCountry() }
        root.addView(countryButton)
        importButton = button("Importer une config WireGuard (.conf)") { pickConfig() }
        root.addView(importButton)
        vpnInfo = label("", 13f)
        root.addView(vpnInfo)
        devButton = button("Autoriser la position fictive") { openDeveloperOptions() }
        root.addView(devButton)

        toggle = button("") { onToggle() }
        root.addView(toggle, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = 24 })

        updateButton = button("Mettre à jour les listes") { updateLists() }
        root.addView(updateButton)
        listInfo = label("", 13f, 8)
        root.addView(listInfo)
        root.addView(label(
            "Filtrage DNS IPv4 expérimental. Désactive le « DNS privé » d'Android et le « DNS sécurisé » de Chrome si rien n'est bloqué.",
            12f, 24
        ))

        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
        applyTheme()
        refresh()
        showListInfo()
    }

    @Suppress("DEPRECATION")
    private fun applyTheme() {
        val bg = if (dark) 0xFF121212.toInt() else 0xFFFAFAFA.toInt()
        val fg = if (dark) 0xFFEEEEEE.toInt() else 0xFF222222.toInt()
        val buttonBg = if (dark) 0xFF2E2E2E.toInt() else 0xFFD6D8D8.toInt()
        root.setBackgroundColor(bg)
        window.decorView.setBackgroundColor(bg)
        texts.forEach { it.setTextColor(fg) }
        checkboxes.forEach { it.buttonTintList = ColorStateList.valueOf(fg) }
        val buttonText = ColorStateList(
            arrayOf(intArrayOf(-android.R.attr.state_enabled), intArrayOf()),
            intArrayOf((fg and 0x00FFFFFF) or 0x66000000, fg)
        )
        for (b in buttons) {
            b.setTextColor(buttonText)
            b.backgroundTintList = ColorStateList.valueOf(buttonBg)
        }
        themeButton.text = if (dark) "☀️" else "🌙"
        // Icônes de la barre d'état / de navigation lisibles dans les deux thèmes
        var flags = window.decorView.systemUiVisibility
        val light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            (if (Build.VERSION.SDK_INT >= 26) View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else 0)
        flags = if (dark) flags and light.inv() else flags or light
        window.decorView.systemUiVisibility = flags
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun isActive() = AdBlockVpnService.isRunning || ToolsService.running

    private fun refresh() {
        val ads = AdBlockVpnService.isRunning
        val tools = ToolsService.running
        val error = ToolsService.lastError
        status.text = when {
            ads -> "Protection active : pubs bloquées"
            tools -> "Protection active : VPN + position" + if (cbAds.isChecked) " + pubs" else ""
            error != null -> error
            else -> "Protection désactivée"
        }
        toggle.text = if (ads || tools) "Désactiver" else "Activer"
        countryButton.text = "Pays : ${Countries.list[countryIndex].label}  ▾"
        val endpoint = WgManager.endpoint(this)
        vpnInfo.text = if (endpoint != null) "Config WireGuard importée • serveur $endpoint"
        else "Aucune config WireGuard importée"
        // Si une erreur arrive alors que le service tourne encore (ex. GPS), on l'ajoute
        if (tools && error != null) status.text = status.text.toString() + "\n⚠ " + error
    }

    // ---------- Activation ----------

    private fun onToggle() {
        if (isActive()) { stopAll(); return }
        val ads = cbAds.isChecked
        val vpn = cbVpn.isChecked
        if (!ads && !vpn) { toast("Coche au moins une option"); return }
        if (vpn && !WgManager.hasConfig(this)) {
            toast("Importe d'abord une config WireGuard (serveur américain)")
            return
        }
        val permission = VpnService.prepare(this)
        if (permission != null) startActivityForResult(permission, REQUEST_VPN) else launch()
    }

    private fun launch() {
        ToolsService.lastError = null
        if (cbVpn.isChecked) {
            val c = Countries.list[countryIndex]
            startForegroundService(
                Intent(this, ToolsService::class.java).setAction(ToolsService.ACTION_START)
                    .putExtra(ToolsService.EXTRA_ADS, cbAds.isChecked)
                    .putExtra(ToolsService.EXTRA_LAT, c.lat)
                    .putExtra(ToolsService.EXTRA_LON, c.lon)
                    .putExtra(ToolsService.EXTRA_LABEL, c.label)
            )
        } else {
            startForegroundService(Intent(this, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_START))
        }
        status.text = "Démarrage…"
        toggle.postDelayed({ refresh() }, 1200)
        toggle.postDelayed({ refresh() }, 3500)
    }

    private fun stopAll() {
        if (AdBlockVpnService.isRunning) {
            startService(Intent(this, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_STOP))
        }
        if (ToolsService.running) {
            startService(Intent(this, ToolsService::class.java).setAction(ToolsService.ACTION_STOP))
        }
        status.text = "Arrêt…"
        toggle.postDelayed({ refresh() }, 800)
        toggle.postDelayed({ refresh() }, 2000)
    }

    // ---------- Pays, config, options développeur ----------

    private fun chooseCountry() {
        AlertDialog.Builder(this)
            .setTitle("Pays")
            .setItems(Countries.list.map { it.label }.toTypedArray()) { _, which ->
                countryIndex = which
                prefs.edit().putInt("country", which).apply()
                refresh()
            }
            .show()
    }

    private fun pickConfig() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
        startActivityForResult(intent, REQUEST_IMPORT)
    }

    private fun importConfig(uri: android.net.Uri) {
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Fichier illisible")
            WgManager.importConfig(this, String(bytes, Charsets.UTF_8))
            toast("Config importée ✔")
        } catch (e: Exception) {
            toast("Config invalide : ${e.message ?: e.javaClass.simpleName}")
        }
        refresh()
    }

    private fun openDeveloperOptions() {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
            toast("Cherche « Sélectionner l'appli de position fictive » → AdSwitch")
        } catch (e: ActivityNotFoundException) {
            toast("Active d'abord les options développeur : Paramètres → À propos du téléphone → touche 7 fois « Numéro de build »")
        }
    }

    // ---------- Listes de blocage ----------

    private fun showListInfo(prefix: String = "") {
        Thread {
            val info = try {
                val store = BlocklistStore(this)
                val count = store.load().size
                val date = java.text.DateFormat.getDateInstance().format(java.util.Date(store.lastModified()))
                "$count domaines bloqués • liste du $date"
            } catch (e: Exception) {
                "Liste indisponible : ${e.message}"
            }
            runOnUiThread { listInfo.text = if (prefix.isEmpty()) info else "$prefix\n$info" }
        }.start()
    }

    private fun updateLists() {
        updateButton.isEnabled = false
        listInfo.text = "Téléchargement en cours…"
        Thread {
            var prefix: String
            try {
                BlocklistStore(this).update()
                prefix = "Mise à jour réussie ✔"
                if (AdBlockVpnService.isRunning) {
                    startService(Intent(this, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_RELOAD))
                }
            } catch (e: Exception) {
                prefix = "Échec de la mise à jour : ${e.message}"
            }
            runOnUiThread {
                updateButton.isEnabled = true
                showListInfo(prefix)
            }
        }.start()
    }

    @Deprecated("Deprecated in Android API; retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_VPN -> if (resultCode == RESULT_OK) launch()
            REQUEST_IMPORT -> data?.data?.let { if (resultCode == RESULT_OK) importConfig(it) }
        }
    }

    companion object {
        private const val REQUEST_VPN = 1001
        private const val REQUEST_IMPORT = 1002
    }
}
