package fr.adswitch.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var toggle: Button

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(32, 48, 32, 32)
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            // Android 15 : l'appli passe sous la barre d'état, on décale le contenu
            setOnApplyWindowInsetsListener { v, insets ->
                v.setPadding(32, 48 + insets.systemWindowInsetTop, 32, 32 + insets.systemWindowInsetBottom)
                insets
            }
        }
        layout.addView(TextView(this).apply { text = "AdSwitch"; textSize = 30f; gravity = Gravity.CENTER })
        layout.addView(TextView(this).apply {
            text = "Bloqueur DNS local • version expérimentale"
            textSize = 15f; gravity = Gravity.CENTER; setPadding(0, 8, 0, 28)
        })
        status = TextView(this).apply { textSize = 17f; gravity = Gravity.CENTER; setPadding(0, 12, 0, 20) }
        toggle = Button(this).apply {
            setOnClickListener {
                if (AdBlockVpnService.isRunning) stopVpn() else {
                    val permission = VpnService.prepare(this@MainActivity)
                    if (permission != null) startActivityForResult(permission, REQUEST_VPN)
                    else startVpn()
                }
            }
        }
        layout.addView(status)
        layout.addView(toggle)
        layout.addView(TextView(this).apply {
            text = "Filtrage DNS IPv4 expérimental. Désactive le « DNS privé » d'Android et le « DNS sécurisé » de Chrome si rien n'est bloqué."
            textSize = 13f; setPadding(0, 24, 0, 0)
        })
        setContentView(layout)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        if (AdBlockVpnService.isRunning) {
            status.text = "Protection active"
            toggle.text = "Désactiver le blocage"
        } else {
            status.text = "Protection désactivée"
            toggle.text = "Activer le blocage"
        }
    }

    private fun startVpn() {
        val intent = Intent(this, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_START)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        status.text = "Démarrage…"
        toggle.postDelayed({ refresh() }, 800)
    }

    private fun stopVpn() {
        startService(Intent(this, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_STOP))
        status.text = "Arrêt…"
        toggle.postDelayed({ refresh() }, 500)
    }

    @Deprecated("Deprecated in Android API; retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_VPN && resultCode == RESULT_OK) startVpn()
    }

    companion object { private const val REQUEST_VPN = 1001 }
}
