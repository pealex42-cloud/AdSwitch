package fr.adswitch.app

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var toggle: Button
    private var active = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(32, 48, 32, 32)
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        layout.addView(TextView(this).apply { text = "AdSwitch"; textSize = 30f; gravity = Gravity.CENTER })
        layout.addView(TextView(this).apply {
            text = "Bloqueur DNS local • version expérimentale"
            textSize = 15f; gravity = Gravity.CENTER; setPadding(0, 8, 0, 28)
        })
        status = TextView(this).apply {
            text = "Protection désactivée"; textSize = 17f; gravity = Gravity.CENTER; setPadding(0, 12, 0, 20)
        }
        toggle = Button(this).apply {
            text = "Activer le blocage"
            setOnClickListener {
                if (active) stopVpn() else {
                    val permission = VpnService.prepare(this@MainActivity)
                    if (permission != null) startActivityForResult(permission, REQUEST_VPN)
                    else startVpn()
                }
            }
        }
        layout.addView(status)
        layout.addView(toggle)
        layout.addView(TextView(this).apply {
            text = "Filtrage DNS IPv4 expérimental. Certains appareils ou applications peuvent utiliser DNS chiffré ou IPv6 et contourner le filtrage."
            textSize = 13f; setPadding(0, 24, 0, 0)
        })
        setContentView(layout)
    }

    private fun startVpn() {
        val intent = Intent(this, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_START)
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        active = true
        status.text = "Démarrage demandé — testez la connexion"
        toggle.text = "Désactiver le blocage"
    }

    private fun stopVpn() {
        startService(Intent(this, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_STOP))
        active = false
        status.text = "Protection désactivée"
        toggle.text = "Activer le blocage"
    }

    @Deprecated("Deprecated in Android API; retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_VPN && resultCode == RESULT_OK) startVpn()
    }

    companion object { private const val REQUEST_VPN = 1001 }
}
