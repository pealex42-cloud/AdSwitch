package fr.adswitch.app

import android.content.Context
import java.io.File

class BlocklistStore(context: Context) {
    private val file = File(context.filesDir, "blocked-hosts.txt")
    private val defaults = setOf(
        "doubleclick.net",
        "googlesyndication.com",
        "googleadservices.com",
        "adservice.google.com",
        "ads.yahoo.com",
        "adnxs.com",
        "scorecardresearch.com",
        "adsrvr.org",
        "taboola.com",
        "outbrain.com",
        "criteo.com",
        "pubmatic.com",
        "rubiconproject.com",
        "openx.net",
        "amazon-adsystem.com",
        "moatads.com",
        "smartadserver.com"
    )

    fun load(): Set<String> {
        if (!file.exists()) saveValidated(defaults)
        return file.readLines().asSequence()
            .map { it.trim().lowercase().trimEnd('.') }
            .filter { it.isNotEmpty() && !it.startsWith("#") && it.length <= 253 && '.' in it && ' ' !in it }
            .toSet()
    }

    fun saveValidated(hosts: Set<String>) {
        val normalized = hosts.asSequence().map { it.trim().lowercase().trimEnd('.') }
            .filter { it.isNotEmpty() && it.length <= 253 && '.' in it && ' ' !in it }
            .distinct().sorted().toList()
        val temp = File(file.parentFile, file.name + ".tmp")
        temp.writeText(normalized.joinToString("\n", postfix = if (normalized.isEmpty()) "" else "\n"))
        if (file.exists() && !file.delete()) { temp.delete(); error("Unable to replace local blocklist") }
        if (!temp.renameTo(file)) error("Unable to commit local blocklist")
    }
}
