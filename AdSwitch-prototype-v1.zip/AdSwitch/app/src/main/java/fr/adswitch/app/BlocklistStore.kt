package fr.adswitch.app

import android.content.Context
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Liste de domaines bloqués.
 * - Au premier lancement : copie de la liste embarquée (assets/blocklist-default.txt).
 * - Mise à jour manuelle : téléchargement HTTPS de la liste StevenBlack, validation,
 *   taille maximale, timeouts, puis remplacement atomique du fichier local.
 */
class BlocklistStore(private val context: Context) {
    private val file = File(context.filesDir, "blocklist-v2.txt")

    /** Charge la liste (la crée depuis les assets si besoin). */
    fun load(): Set<String> = synchronized(LOCK) {
        if (!file.exists()) {
            val text = context.assets.open(ASSET).bufferedReader().use { it.readText() }
            writeAtomically(text)
        }
        parse(file.readText())
    }

    /** Date de dernière mise à jour du fichier local, ou 0 s'il n'existe pas encore. */
    fun lastModified(): Long = if (file.exists()) file.lastModified() else 0L

    /** Télécharge et installe la liste. Retourne le nombre de domaines. Lève une exception en cas d'échec. */
    fun update(): Int {
        val conn = URL(SOURCE_URL).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 10_000
            conn.readTimeout = 20_000
            if (conn.responseCode != 200) error("Serveur : HTTP ${conn.responseCode}")
            if (conn.contentLengthLong > MAX_BYTES) error("Fichier trop volumineux")
            val out = ByteArrayOutputStream()
            conn.inputStream.use { input ->
                val buf = ByteArray(16 * 1024)
                var total = 0L
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > MAX_BYTES) error("Fichier trop volumineux")
                    out.write(buf, 0, n)
                }
            }
            val domains = parse(out.toString("UTF-8"))
            if (domains.size < MIN_DOMAINS) error("Liste reçue invalide (${domains.size} domaines)")
            synchronized(LOCK) {
                writeAtomically(domains.sorted().joinToString("\n", postfix = "\n"))
            }
            return domains.size
        } finally {
            conn.disconnect()
        }
    }

    private fun writeAtomically(text: String) {
        val temp = File(file.parentFile, file.name + ".tmp")
        temp.writeText(text)
        if (!temp.renameTo(file)) {
            temp.delete()
            error("Impossible d'enregistrer la liste")
        }
    }

    /** Accepte le format "domaine" ou le format hosts "0.0.0.0 domaine". */
    private fun parse(text: String): Set<String> {
        val result = HashSet<String>(100_000)
        for (raw in text.lineSequence()) {
            val line = raw.substringBefore('#').trim()
            if (line.isEmpty()) continue
            val parts = line.split(WHITESPACE)
            val domain = when {
                parts.size == 1 -> parts[0]
                parts.size >= 2 && (parts[0] == "0.0.0.0" || parts[0] == "127.0.0.1") -> parts[1]
                else -> continue
            }.lowercase().trimEnd('.')
            if (domain.length <= 253 && '.' in domain && DOMAIN.matches(domain) && !NUMERIC.matches(domain)) {
                result.add(domain)
            }
        }
        return result
    }

    companion object {
        private const val ASSET = "blocklist-default.txt"
        private const val SOURCE_URL = "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"
        private const val MAX_BYTES = 15L * 1024 * 1024
        private const val MIN_DOMAINS = 5_000
        private val LOCK = Any()
        private val WHITESPACE = Regex("\\s+")
        private val DOMAIN = Regex("[a-z0-9]([a-z0-9._-]*[a-z0-9])?")
        private val NUMERIC = Regex("[0-9.]+")
    }
}
