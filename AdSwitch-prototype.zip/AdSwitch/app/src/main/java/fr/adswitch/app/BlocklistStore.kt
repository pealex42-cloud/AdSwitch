package fr.adswitch.app

import android.content.Context
import java.io.File

/**
 * Minimal local storage for normalized blocked hostnames.
 * The network updater and validation/atomic replacement will be added next.
 */
class BlocklistStore(context: Context) {
    private val file = File(context.filesDir, "blocked-hosts.txt")

    fun load(): Set<String> {
        if (!file.exists()) return emptySet()
        return file.readLines()
            .asSequence()
            .map { it.trim().lowercase() }
            .filter { it.isNotEmpty() && !it.startsWith("#") && '.' in it && ' ' !in it }
            .toSet()
    }

    fun saveValidated(hosts: Set<String>) {
        val normalized = hosts.asSequence()
            .map { it.trim().lowercase().trimEnd('.') }
            .filter { it.isNotEmpty() && it.length <= 253 && '.' in it }
            .distinct()
            .sorted()
            .toList()

        val temp = File(file.parentFile, file.name + ".tmp")
        temp.writeText(normalized.joinToString(separator = "\n", postfix = if (normalized.isEmpty()) "" else "\n"))
        if (file.exists() && !file.delete()) {
            temp.delete()
            error("Unable to replace local blocklist")
        }
        if (!temp.renameTo(file)) error("Unable to commit local blocklist")
    }
}
