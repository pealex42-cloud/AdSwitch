package fr.adswitch.app

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(32, 48, 32, 32)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val title = TextView(this).apply {
            text = "AdSwitch"
            textSize = 30f
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Bloqueur DNS local • prototype"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 28)
        }
        status = TextView(this).apply {
            text = "Moteur de filtrage non activé"
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 20)
        }
        val start = Button(this).apply {
            text = "Autoriser le VPN local"
            setOnClickListener {
                val intent = VpnService.prepare(this@MainActivity)
                if (intent != null) startActivityForResult(intent, REQUEST_VPN)
                else onVpnPermissionGranted()
            }
        }
        val update = Button(this).apply {
            text = "Mettre à jour les listes (à implémenter)"
            isEnabled = false
        }
        val note = TextView(this).apply {
            text = "Prototype de départ : le moteur réseau doit être finalisé et testé avant toute activation réelle. Aucun filtrage n'est effectué pour le moment."
            textSize = 13f
            setPadding(0, 24, 0, 0)
        }

        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(status)
        layout.addView(start)
        layout.addView(update)
        layout.addView(note)
        setContentView(layout)
    }

    @Deprecated("Deprecated in Android API; retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_VPN && resultCode == RESULT_OK) onVpnPermissionGranted()
    }

    private fun onVpnPermissionGranted() {
        status.text = "Autorisation accordée — moteur à finaliser"
        // Deliberately does not start a VPN until packet forwarding/filtering is implemented.
    }

    companion object { private const val REQUEST_VPN = 1001 }
}
