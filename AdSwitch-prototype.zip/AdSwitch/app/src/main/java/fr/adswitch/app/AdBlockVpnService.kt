package fr.adswitch.app

import android.net.VpnService

/**
 * Service declaration for the future local DNS filtering engine.
 *
 * Important: this scaffold intentionally does not establish a TUN interface yet.
 * A production implementation must correctly parse and answer DNS packets and
 * forward allowed queries without creating a network loop before it is enabled.
 */
class AdBlockVpnService : VpnService()
